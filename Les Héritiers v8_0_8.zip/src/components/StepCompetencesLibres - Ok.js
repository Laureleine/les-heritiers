// src/components/StepCompetencesLibres.js
// Version: 3.6.4
// Build: 2026-02-07 16:00
// Description: Base v3.6.3 (Calculs PP + Design) + Règle Bonus Esprit (Livre de Base p.44/72)

import React from 'react';
import { Plus, Minus, Star, Target, ShieldCheck, Coins, Brain } from 'lucide-react';

const POINTS_TOTAUX = 15;

// Liste des compétences éligibles au Bonus Esprit (Profils Érudit et Savant)
const COMPETENCES_BONUS_LIST = [
  'Culture', 'Occultisme', 'Fortitude', 'Rhétorique', // Érudit
  'Habiletés', 'Médecine', 'Sciences', 'Observation'  // Savant
];

export default function StepCompetencesLibres({ 
  character, 
  onCompetencesLibresChange, 
  profils, 
  competences, 
  competencesParProfil, 
  fairyData 
}) {
  const feeData = fairyData[character.typeFee];
  const lib = character.competencesLibres || { rangs: {}, choixPredilection: {}, choixSpecialite: {}, choixSpecialiteUser: {} };

  // --- 1. CALCUL DU BUDGET (NOUVELLE LOGIQUE ESPRIT) ---

  // A. Calcul du montant du bonus (Esprit - 3)
  const scoreEsprit = character.caracteristiques?.esprit || 3;
  const POINTS_BONUS_ESPRIT_MAX = Math.max(0, scoreEsprit - 3);

  // B. Calcul des dépenses réparties (Bonus vs Général)
  let coutBonusUtilise = 0;
  let coutGeneralUtilise = 0;

  // Parcours des rangs achetés
  Object.entries(lib.rangs || {}).forEach(([nomComp, valeur]) => {
    let coutLigne = valeur; // Coût des rangs
    
    // Ajout du coût des spécialités achetées par l'utilisateur pour cette compétence
    const userSpecs = lib.choixSpecialiteUser?.[nomComp] || [];
    coutLigne += userSpecs.length;

    if (coutLigne > 0) {
      if (COMPETENCES_BONUS_LIST.includes(nomComp)) {
        // C'est une compétence Érudit/Savant : on utilise le bonus dispo
        const resteBonus = POINTS_BONUS_ESPRIT_MAX - coutBonusUtilise;
        const partBonus = Math.min(coutLigne, resteBonus);
        
        coutBonusUtilise += partBonus;
        coutGeneralUtilise += (coutLigne - partBonus);
      } else {
        // Compétence standard : tout sur le général
        coutGeneralUtilise += coutLigne;
      }
    }
  });

  // C. Soldes restants
  const pointsRestantsGeneral = POINTS_TOTAUX - coutGeneralUtilise;
  const pointsRestantsBonus = POINTS_BONUS_ESPRIT_MAX - coutBonusUtilise;

  // --- 2. PRÉDILECTIONS (LOGIQUE v3.6.3 CONSERVÉE) ---

  const getPredilectionsFinales = () => {
    if (!feeData?.competencesPredilection) return [];
    return feeData.competencesPredilection.map((p, i) => {
      if (p.isChoix) return lib.choixPredilection?.[i];
      return p.nom;
    }).filter(Boolean);
  };

  const predFinales = getPredilectionsFinales();

  // --- 3. SCORE DE BASE (LOGIQUE v3.6.3 CONSERVÉE) ---

  const getScoreBase = (nomComp) => {
    let base = 0;
    if (predFinales.includes(nomComp)) base += 2;
    if (character.profils.majeur.competences?.includes(nomComp)) base += 2;
    if (character.profils.mineur.competences?.includes(nomComp)) base += 1;
    return base;
  };

  // --- 4. CALCUL RANG DE PROFIL (LOGIQUE v3.6.3 CONSERVÉE) ---

  const calculateProfilStats = (profilNom, isMajeur, isMineur) => {
    const compsDuProfil = competencesParProfil[profilNom] || [];
    let sommeScores = 0;

    compsDuProfil.forEach(c => {
      const base = getScoreBase(c.nom);
      const investi = lib.rangs[c.nom] || 0;
      sommeScores += (base + investi);
    });

    const rang = Math.floor(sommeScores / 4); // Règle : Moyenne arrondie à l'inférieur
    const bonusFixe = isMajeur ? 8 : isMineur ? 4 : 0;
    const totalPP = rang + bonusFixe;

    return { rang, bonusFixe, totalPP };
  };

  // --- HANDLERS (MIS À JOUR AVEC DOUBLE BUDGET) ---

  const canSpendPoint = (nomComp) => {
    const isEligibleBonus = COMPETENCES_BONUS_LIST.includes(nomComp);
    // On peut dépenser si on a du général OU (c'est éligible ET on a du bonus)
    return pointsRestantsGeneral > 0 || (isEligibleBonus && pointsRestantsBonus > 0);
  };

  const handleRangChange = (nomComp, delta) => {
    const current = lib.rangs[nomComp] || 0;
    const isPred = predFinales.includes(nomComp);
    const max = isPred ? 5 : 4;
    const totalScore = getScoreBase(nomComp) + current;

    // Blocage : Plus de budget OU Max atteint
    if (delta > 0) {
      if (!canSpendPoint(nomComp)) return;
      if (totalScore >= max) return;
    }
    if (delta < 0 && current <= 0) return;

    onCompetencesLibresChange({
      ...lib,
      rangs: { ...lib.rangs, [nomComp]: current + delta }
    });
  };

  const handleChoixChange = (index, value, type) => {
    const target = type === 'competence' ? 'choixPredilection' : 'choixSpecialite';
    onCompetencesLibresChange({
      ...lib,
      [target]: { ...lib[target], [index]: value }
    });
  };

  const handleAddSpecialiteUser = (nomComp, specName) => {
    if (!specName) return;
    // Vérification budget double
    if (!canSpendPoint(nomComp)) return;

    const currentSpecs = lib.choixSpecialiteUser?.[nomComp] || [];
    if (currentSpecs.includes(specName)) return;

    onCompetencesLibresChange({
      ...lib,
      choixSpecialiteUser: {
        ...lib.choixSpecialiteUser,
        [nomComp]: [...currentSpecs, specName]
      }
    });
  };

  const handleRemoveSpecialiteUser = (nomComp, specName) => {
    const currentSpecs = lib.choixSpecialiteUser?.[nomComp] || [];
    onCompetencesLibresChange({
      ...lib,
      choixSpecialiteUser: {
        ...lib.choixSpecialiteUser,
        [nomComp]: currentSpecs.filter(s => s !== specName)
      }
    });
  };

  // --- RENDER ROW (DESIGN v3.6.3 CONSERVÉ) ---

  const renderCompRow = (nomComp) => {
    const scoreBase = getScoreBase(nomComp);
    const investis = lib.rangs[nomComp] || 0;
    const total = scoreBase + investis;
    const isPred = predFinales.includes(nomComp);
    
    // Calcul pour l'état disabled
    const maxAtteint = total >= (isPred ? 5 : 4);
    const canBuy = canSpendPoint(nomComp) && !maxAtteint;

// Calcul de la spécialité offerte (soit fixe, soit choisie par le joueur)
    let fairySpecFixe = null;
    
    // On cherche dans la config du type de fée
    const predData = feeData?.competencesPredilection?.find(p => p.nom === nomComp);
    const predIndex = feeData?.competencesPredilection?.findIndex(p => p.nom === nomComp);

    if (predData) {
      if (predData.specialite) {
        // Cas A : Spécialité imposée (ex: Nage pour Ondine)
        fairySpecFixe = predData.specialite;
      } else if (predData.isSpecialiteChoix && predIndex !== -1) {
        // Cas B : Spécialité choisie (ex: Gargouille) -> On regarde le choix utilisateur
        fairySpecFixe = lib.choixSpecialite?.[predIndex];
      }
    }

    // ... suite du code (userSpecs, availableSpecs...)

    const userSpecs = lib.choixSpecialiteUser?.[nomComp] || [];
    const availableSpecs = competences[nomComp]?.specialites || [];
    
    // Indicateur visuel Bonus Esprit
    const isBonusEligible = COMPETENCES_BONUS_LIST.includes(nomComp) && POINTS_BONUS_ESPRIT_MAX > 0;

    return (
      <div key={nomComp} className={`p-2 rounded border mb-2 flex flex-col ${
        investis > 0 || userSpecs.length > 0 ? (isBonusEligible && pointsRestantsBonus >= 0 ? 'bg-blue-50/30 border-blue-200' : 'bg-white border-amber-300') : 'bg-white border-gray-100'
      }`}>
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-1 font-serif text-gray-800">
            {nomComp}
            {isPred && <Star size={12} className="text-purple-600 fill-purple-600" />}
            {isBonusEligible && <Brain size={12} className="text-blue-500" title="Éligible au Bonus Esprit" />}
          </div>
          
          <div className="flex items-center gap-2 text-xs">
            <span className="text-gray-400">Base {scoreBase}</span>
            {investis > 0 && <span className="text-amber-600 font-bold">+{investis} pts</span>}
            
            <div className="flex items-center border rounded bg-white">
              <button onClick={() => handleRangChange(nomComp, -1)} disabled={investis <= 0} className="px-2 py-1 hover:bg-red-100 text-amber-800 disabled:opacity-30 border-r border-amber-200">
                <Minus size={14} />
              </button>
              <span className="w-6 text-center font-bold">{total}</span>
              <button onClick={() => handleRangChange(nomComp, 1)} disabled={!canBuy} className="px-2 py-1 hover:bg-green-100 text-amber-800 disabled:opacity-30 border-l border-amber-200">
                <Plus size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Zone Spécialités */}
        <div className="flex flex-wrap gap-1 mt-1 pl-1">
          {fairySpecFixe && (
            <span className="text-[10px] bg-purple-100 text-purple-800 px-1.5 rounded border border-purple-200">{fairySpecFixe}</span>
          )}
          {userSpecs.map(spec => (
            <span key={spec} className="text-[10px] bg-amber-100 text-amber-800 px-1.5 rounded border border-amber-200 flex items-center gap-1">
              {spec}
              <button onClick={() => handleRemoveSpecialiteUser(nomComp, spec)} className="hover:text-red-600 font-bold ml-1">×</button>
            </span>
          ))}
        </div>

        {/* Achat Spécialité */}
        {availableSpecs.length > 0 && (
          <select 
            className="w-full text-[10px] p-1 border rounded bg-gray-50 font-serif text-gray-500 outline-none focus:border-amber-400 mt-1 cursor-pointer"
            onChange={(e) => { if(e.target.value) { handleAddSpecialiteUser(nomComp, e.target.value); e.target.value = ""; }}}
            disabled={!canSpendPoint(nomComp)}
          >
            <option value="">+ Acheter spécialité (1 pt)</option>
            {availableSpecs.filter(s => !userSpecs.includes(s) && s !== fairySpecFixe).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      
      {/* HEADER STICKY AVEC COMPTEURS DOUBLES */}
      <div className="sticky top-0 z-10 bg-white p-4 rounded-xl border border-amber-200 shadow-md flex justify-between items-center gap-4">
        
        {/* Compteur Général */}
        <div className="flex-1 text-center">
          <div className="text-xs uppercase text-gray-500 font-bold tracking-wider mb-1">Points Libres</div>
          <div className={`text-3xl font-serif font-bold ${pointsRestantsGeneral < 0 ? 'text-red-600' : 'text-amber-600'}`}>
            {pointsRestantsGeneral} <span className="text-sm font-sans text-gray-400">/ 15</span>
          </div>
        </div>

        {/* Compteur Bonus Esprit (affiché seulement si pertinent) */}
        {POINTS_BONUS_ESPRIT_MAX > 0 && (
          <div className="flex-1 text-center border-l border-gray-200">
            <div className="text-xs uppercase text-blue-600 font-bold tracking-wider mb-1 flex items-center justify-center gap-1">
              <Brain size={14}/> Bonus Esprit
            </div>
            <div className={`text-3xl font-serif font-bold ${pointsRestantsBonus < 0 ? 'text-red-600' : 'text-blue-600'}`}>
              {pointsRestantsBonus} <span className="text-sm font-sans text-gray-400">/ {POINTS_BONUS_ESPRIT_MAX}</span>
            </div>
            <div className="text-[9px] text-blue-400 leading-tight">Pour Érudit & Savant</div>
          </div>
        )}
      </div>

      {/* Choix Héritage (v3.6.3) */}
{feeData.competencesPredilection.map((p, i) => {
  // Cas 1 : Choix de la compétence (ex: Ange - Mêlée ou Tir)
  if (p.isChoix) return (
    <div key={i} className="mb-2">
      <label className="text-sm text-purple-800 block mb-1">Prédilection au choix :</label>
      <select 
        className="w-full p-2 border rounded font-serif shadow-sm"
        value={lib.choixPredilection?.[i] || ''}
        onChange={(e) => handleChoixChange(i, e.target.value, 'competence')}
      >
        <option value="">-- Sélectionner --</option>
        {p.options.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );

  // Cas 2 : Choix de la spécialité (ex: Gargouille - Sciences occultes ou Spiritisme)
  // --- C'EST CE BLOC QUI MANQUAIT ---
  else if (p.isSpecialiteChoix) return (
    <div key={i} className="mb-2">
      <label className="text-sm text-purple-800 block mb-1">
        Spécialité pour {p.nom} :
      </label>
      <select 
        className="w-full p-2 border rounded font-serif shadow-sm"
        value={lib.choixSpecialite?.[i] || ''}
        onChange={(e) => handleChoixChange(i, e.target.value, 'specialite')}
      >
        <option value="">-- Sélectionner --</option>
        {p.optionsSpecialite.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
  
  return null;
})}

      {/* Grille Profils (v3.6.3 + Design) */}
      <div className="grid md:grid-cols-2 gap-6">
        {profils.map(profil => {
          const isMajeur = character.profils.majeur.nom === profil.nom;
          const isMineur = character.profils.mineur.nom === profil.nom;
          const stats = calculateProfilStats(profil.nom, isMajeur, isMineur);
          
          return (
            <div key={profil.nom} className={`rounded-xl border overflow-hidden transition-all ${
              isMajeur ? 'border-amber-400 bg-amber-50/50' : isMineur ? 'border-blue-300 bg-blue-50/30' : 'border-gray-200 bg-gray-50/50'
            }`}>
              {/* EN-TÊTE AVEC CALCUL PP */}
              <div className="px-4 py-2 bg-white/80 border-b border-gray-100 flex justify-between items-center">
                <div className={`font-bold flex items-center gap-2 ${isMajeur ? 'text-amber-900' : isMineur ? 'text-blue-900' : 'text-gray-500'}`}>
                  {profil.icon} {profil.nom}
                  {isMajeur && <span className="text-[10px] bg-amber-100 px-1 rounded border border-amber-200">Majeur (+2)</span>}
                  {isMineur && <span className="text-[10px] bg-blue-100 px-1 rounded border border-blue-200">Mineur (+1)</span>}
                </div>
                <div className="text-[10px] font-mono text-gray-500 bg-gray-100 px-2 py-1 rounded" title="Rang calculé + Bonus Profil = Points Personnage">
                  Rang {stats.rang} + {stats.bonusFixe} = <strong>{stats.totalPP} PP</strong>
                </div>
              </div>

              <div className="p-3">
                {(competencesParProfil[profil.nom] || []).map(comp => renderCompRow(comp.nom))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}