// src/utils/notificationSystem.js
// Version: 2.6.0
// Build: 2026-01-31 19:50

import { supabase } from '../config/supabase';

/**
 * Demande la permission pour les notifications push
 */
export const requestNotificationPermission = async () => {
  if (!('Notification' in window)) {
    console.log('Ce navigateur ne supporte pas les notifications');
    return false;
  }

  if (Notification.permission === 'granted') {
    return true;
  }

  if (Notification.permission !== 'denied') {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }

  return false;
};

/**
 * Enregistre le token de notification push dans Supabase
 */
export const saveNotificationToken = async (userId, token) => {
  try {
    await supabase
      .from('user_notification_preferences')
      .upsert({
        user_id: userId,
        push_notification_token: token,
        enable_push_notifications: true,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'user_id'
      });
    return true;
  } catch (error) {
    console.error('Erreur sauvegarde token:', error);
    return false;
  }
};

/**
 * Envoie une notification push locale (dans le navigateur)
 */
export const sendLocalNotification = (title, options = {}) => {
  if (Notification.permission === 'granted') {
    const notification = new Notification(title, {
      icon: '/logo192.png',
      badge: '/logo192.png',
      ...options
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };

    return notification;
  }
};

/**
 * Affiche une notification in-app (dans l'interface)
 */
export const showInAppNotification = (message, type = 'info') => {
  const event = new CustomEvent('app-notification', {
    detail: { message, type }
  });
  window.dispatchEvent(event);
};

/**
 * Créer une notification pour une nouvelle version
 */
export const notifyNewVersion = (version, changelog) => {
  // Notification push navigateur
  sendLocalNotification(
    '🎭 Les Héritiers - Nouvelle version !',
    {
      body: `Version ${version} disponible`,
      tag: `version-${version}`,
      requireInteraction: true,
      actions: [
        { action: 'view', title: 'Voir les changements' },
        { action: 'close', title: 'Plus tard' }
      ]
    }
  );

  // Notification in-app
  showInAppNotification(
    `Nouvelle version ${version} disponible ! Cliquez pour voir les changements.`,
    'success'
  );
};

/**
 * Vérifie s'il y a une nouvelle version (à appeler au démarrage)
 * Note: Désactivé car version.json n'est pas déployé en production
 * TODO: Implémenter vérification version avec API backend
 */
export const checkForUpdates = async (currentVersion) => {
  // Désactivé pour éviter erreur 404
  return;
};


/**
* Service Worker pour notifications en arrière-plan
*/
export const registerServiceWorker = async () => {
  // NOUVEAU : On bloque le Service Worker si on est en local !
  if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    console.log('🚧 Mode Local détecté : Service Worker désactivé pour faciliter le développement.');
    return;
  }

  // Le code normal s'exécutera uniquement en production
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('✅ Service Worker enregistré:', registration);
      return registration;
    } catch (error) {
      console.error('❌ Erreur Service Worker:', error);
    }
  }
};
